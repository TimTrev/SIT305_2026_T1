package com.example.travelcompanionapp;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    //UI components
    private Spinner spinnerCategory, spinnerFrom, spinnerTo;
    private EditText etInput;
    private Button btnConvert;
    private TextView tvResult;

    //Conversion categories and their units for the first spinner
    private final String[] categories = {"Currency", "Fuel & Distance", "Temperature"};
    private final String[] currencyUnits = {"USD", "AUD", "EUR", "JPY", "GBP"};
    private final String[] fuelDistanceUnits = {"mpg", "km/L", "Gallon", "Liter", "Nautical Mile", "Kilometer"};
    private final String[] temperatureUnits = {"Celsius", "Fahrenheit", "Kelvin"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Links this java file to the activity_main.xml

        //Connects the variables to the actual view
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        etInput = findViewById(R.id.etInput);
        btnConvert = findViewById(R.id.btnConvert);
        tvResult = findViewById(R.id.tvResult);

        setSpinnerData(spinnerCategory, categories);
        updateUnitSpinners("Currency");

        //A listener for when the user changes the category
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = spinnerCategory.getSelectedItem().toString();
                updateUnitSpinners(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //A listener for when the user changes the "From" unit
        //Used in my ValidUnitAdapter.java for fuel & distance options
        spinnerFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String category = spinnerCategory.getSelectedItem().toString();

                if (category.equals("Fuel & Distance")) {
                    String fromUnit = spinnerFrom.getSelectedItem().toString();
                    updateToSpinnerForFuelDistance(fromUnit);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //Performs conversion logic when the button is pressed
        btnConvert.setOnClickListener(v -> performConversion());
    }

    //Helper method that loads a list of items into a spinner
    private void setSpinnerData(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                items
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    //Changes the 'From' and 'To' units depending on category selection
    private void updateUnitSpinners(String category) {
        switch (category) {
            case "Currency":
                setSpinnerData(spinnerFrom, currencyUnits);
                setSpinnerData(spinnerTo, currencyUnits);
                break;

            case "Fuel & Distance":
                setSpinnerData(spinnerFrom, fuelDistanceUnits);
                updateToSpinnerForFuelDistance(fuelDistanceUnits[0]);
                break;

            case "Temperature":
                setSpinnerData(spinnerFrom, temperatureUnits);
                setSpinnerData(spinnerTo, temperatureUnits);
                break;
        }
    }

    //Method only for Fuel & Distance
    //Keeps all units visible to spinner yet only enables the valid matching pair
    private void updateToSpinnerForFuelDistance(String fromUnit) {
        Set<String> validToUnits = new HashSet<>();

        switch (fromUnit) {
            case "mpg":
                validToUnits.add("km/L");
                break;

            case "km/L":
                validToUnits.add("mpg");
                break;

            case "Gallon":
                validToUnits.add("Liter");
                break;

            case "Liter":
                validToUnits.add("Gallon");
                break;

            case "Nautical Mile":
                validToUnits.add("Kilometer");
                break;

            case "Kilometer":
                validToUnits.add("Nautical Mile");
                break;
        }

        //Grays out invalid items
        ValidUnitAdapter adapter = new ValidUnitAdapter(this, fuelDistanceUnits, validToUnits);
        spinnerTo.setAdapter(adapter);

        //Automatically updates the spinner to select the first valid unit
        if (!validToUnits.isEmpty()) {
            String firstValid = validToUnits.iterator().next();
            for (int i = 0; i < fuelDistanceUnits.length; i++) {
                if (fuelDistanceUnits[i].equals(firstValid)) {
                    spinnerTo.setSelection(i);
                    break;
                }
            }
        }
    }

    //Main conversion method when convert button is pressed
    private void performConversion() {
        String category = spinnerCategory.getSelectedItem().toString();
        String from = spinnerFrom.getSelectedItem().toString();
        String to = spinnerTo.getSelectedItem().toString();
        String inputText = etInput.getText().toString().trim();

        if (inputText.isEmpty()) {
            etInput.setError("Please enter a value");
            return;
        }

        double inputValue;

        //Tries to convert the text input into a number
        try {
            inputValue = Double.parseDouble(inputText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        //If user selects the same unit, no conversion is needed
        if (from.equals(to)) {
            tvResult.setText(String.format(Locale.US, "Result: %.2f", inputValue));
            Toast.makeText(this, "Source and destination are the same", Toast.LENGTH_SHORT).show();
            return;
        }

        //Extra validation for Fuel & Distance
        if (category.equals("Fuel & Distance")) {
            if (!isValidFuelDistancePair(from, to)) {
                Toast.makeText(this, "Invalid conversion pair selected", Toast.LENGTH_SHORT).show();
                return;
            }

            if ((from.equals("mpg") || to.equals("mpg") || from.equals("km/L") || to.equals("km/L")) && inputValue < 0) {
                Toast.makeText(this, "Fuel efficiency cannot be negative", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        double result;

        //sends the input to the correct conversion method based on category
        switch (category) {
            case "Currency":
                result = convertCurrency(from, to, inputValue);
                break;

            case "Fuel & Distance":
                result = convertFuelDistance(from, to, inputValue);
                break;

            case "Temperature":
                result = convertTemperature(from, to, inputValue);
                break;

            default:
                Toast.makeText(this, "Invalid category selected", Toast.LENGTH_SHORT).show();
                return;
        }
        //Outputs final converted result
        tvResult.setText(String.format(Locale.US, "Result: %.2f", result));
    }

    //Checks if the selected Fuel & Distance conversion pairs are valid
    private boolean isValidFuelDistancePair(String from, String to) {
        return (from.equals("mpg") && to.equals("km/L")) ||
                (from.equals("km/L") && to.equals("mpg")) ||
                (from.equals("Gallon") && to.equals("Liter")) ||
                (from.equals("Liter") && to.equals("Gallon")) ||
                (from.equals("Nautical Mile") && to.equals("Kilometer")) ||
                (from.equals("Kilometer") && to.equals("Nautical Mile"));
    }

    //Currency conversion using fixed exchange rates
    //Always converted to USD first, then from USD to the targeted currency
    private double convertCurrency(String from, String to, double amount) {
        Map<String, Double> usdRates = new HashMap<>();
        usdRates.put("USD", 1.00);
        usdRates.put("AUD", 1.55);
        usdRates.put("EUR", 0.92);
        usdRates.put("JPY", 148.50);
        usdRates.put("GBP", 0.78);

        double amountInUsd = amount / usdRates.get(from);
        return amountInUsd * usdRates.get(to);
    }

    //Fuel & Distance conversion using the fixed values
    private double convertFuelDistance(String from, String to, double value) {
        if (from.equals("mpg") && to.equals("km/L")) {
            return value * 0.425;
        } else if (from.equals("km/L") && to.equals("mpg")) {
            return value / 0.425;
        } else if (from.equals("Gallon") && to.equals("Liter")) {
            return value * 3.785;
        } else if (from.equals("Liter") && to.equals("Gallon")) {
            return value / 3.785;
        } else if (from.equals("Nautical Mile") && to.equals("Kilometer")) {
            return value * 1.852;
        } else if (from.equals("Kilometer") && to.equals("Nautical Mile")) {
            return value / 1.852;
        } else {
            throw new IllegalArgumentException("Unsupported conversion");
        }
    }

    //Temperate conversion formulas
    private double convertTemperature(String from, String to, double value) {
        if (from.equals("Celsius") && to.equals("Fahrenheit")) {
            return (value * 1.8) + 32;
        } else if (from.equals("Celsius") && to.equals("Kelvin")) {
            return value + 273.15;
        } else if (from.equals("Fahrenheit") && to.equals("Celsius")) {
            return (value - 32) / 1.8;
        } else if (from.equals("Fahrenheit") && to.equals("Kelvin")) {
            return ((value - 32) / 1.8) + 273.15;
        } else if (from.equals("Kelvin") && to.equals("Celsius")) {
            return value - 273.15;
        } else if (from.equals("Kelvin") && to.equals("Fahrenheit")) {
            return ((value - 273.15) * 1.8) + 32;
        } else {
            throw new IllegalArgumentException("Unsupported conversion");
        }
    }
}