package com.example.travelcompanionapp;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Set;

//Custom spinner adapter used for Fuel & Distance
//Grays out invalid destination units to prevent them being selected
public class ValidUnitAdapter extends ArrayAdapter<String> {

    //Stores the units that are allowed to be selected
    private final Set<String> enabledItems;

    public ValidUnitAdapter(Context context, String[] items, Set<String> enabledItems) {
        super(context, android.R.layout.simple_spinner_item, items);
        this.enabledItems = enabledItems;
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }

    //Controls whether a specific item can be selected
    @Override
    public boolean isEnabled(int position) {
        String item = getItem(position);
        return item != null && enabledItems.contains(item);
    }

    @NonNull
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = super.getDropDownView(position, convertView, parent);
        TextView textView = (TextView) view;

        String item = getItem(position);

        if (item != null && enabledItems.contains(item)) {
            textView.setTextColor(Color.BLACK);
        } else {
            textView.setTextColor(Color.GRAY);
        }

        return view;
    }
}