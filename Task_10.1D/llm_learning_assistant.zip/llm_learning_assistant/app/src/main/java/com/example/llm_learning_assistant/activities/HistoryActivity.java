package com.example.llm_learning_assistant.activities;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

public class HistoryActivity extends AppCompatActivity {

    private Button btnBackHistory;
    private LinearLayout layoutHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        btnBackHistory = findViewById(R.id.btnBackHistory);
        layoutHistory = findViewById(R.id.layoutHistory);

        btnBackHistory.setOnClickListener(v -> finish());

        loadHistory();
    }

    private void loadHistory() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        int count = prefs.getInt("history_count", 0);

        if (count == 0) {
            TextView empty = new TextView(this);
            empty.setText("No quiz history yet.");
            empty.setTextSize(18f);
            empty.setTextColor(getColor(android.R.color.black));
            layoutHistory.addView(empty);
            return;
        }

        for (int i = count; i >= 1; i--) {
            final int historyId = i;

            String topic = prefs.getString("history_topic_" + i, "Unknown Topic");
            int score = prefs.getInt("history_score_" + i, 0);
            int total = prefs.getInt("history_total_" + i, 0);
            boolean hintUsed = prefs.getBoolean("history_hint_used_" + i, false);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(24, 20, 24, 20);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.bottomMargin = 18;
            card.setLayoutParams(params);
            card.setBackgroundResource(R.drawable.blue_card);
            card.setClickable(true);

            TextView title = new TextView(this);
            title.setText(i + ". " + topic);
            title.setTextColor(getColor(android.R.color.white));
            title.setTextSize(19f);
            title.setTypeface(null, Typeface.BOLD);

            TextView result = new TextView(this);
            result.setText("Score: " + score + " / " + total + "\nHint Used: " + (hintUsed ? "Yes ✓" : "No"));
            result.setTextColor(getColor(android.R.color.white));
            result.setTextSize(16f);
            result.setPadding(0, 8, 0, 0);

            card.addView(title);
            card.addView(result);

            card.setOnClickListener(v -> showHistoryDetails(historyId));

            layoutHistory.addView(card);
        }
    }

    private void showHistoryDetails(int historyId) {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);

        String topic = prefs.getString("history_topic_" + historyId, "Unknown Topic");
        int total = prefs.getInt("history_total_" + historyId, 0);
        boolean hintUsed = prefs.getBoolean("history_hint_used_" + historyId, false);

        StringBuilder details = new StringBuilder();
        details.append("Topic: ").append(topic).append("\n");
        details.append("Hint Used: ").append(hintUsed ? "Yes ✓" : "No").append("\n\n");

        for (int i = 1; i <= total; i++) {
            String question = prefs.getString("history_" + historyId + "_question_" + i, "Question unavailable");
            String selected = prefs.getString("history_" + historyId + "_selected_" + i, "No answer selected");
            String correct = prefs.getString("history_" + historyId + "_correct_" + i, "Correct answer unavailable");
            boolean isCorrect = prefs.getBoolean("history_" + historyId + "_is_correct_" + i, false);

            details.append("Question ").append(i).append(":\n");
            details.append(question).append("\n");
            details.append("Your Answer: ").append(selected).append("\n");
            details.append("Correct Answer: ").append(correct).append("\n");
            details.append("Result: ").append(isCorrect ? "Correct ✓" : "Incorrect ✗").append("\n\n");
        }

        new AlertDialog.Builder(this)
                .setTitle("Quiz History Details")
                .setMessage(details.toString())
                .setPositiveButton("OK", null)
                .show();
    }
}