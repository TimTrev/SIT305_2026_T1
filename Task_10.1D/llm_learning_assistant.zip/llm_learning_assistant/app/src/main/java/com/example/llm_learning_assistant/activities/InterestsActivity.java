package com.example.llm_learning_assistant.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class InterestsActivity extends AppCompatActivity {

    private TextView tvTopicCount;
    private TextView tvAlgorithms, tvDataStructures, tvWebDevelopment, tvTesting, tvAndroid;
    private Button btnNextToTasks;

    private final ArrayList<String> selectedInterests = new ArrayList<>();
    private final Map<TextView, String> topicMap = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interests);

        tvTopicCount = findViewById(R.id.tvTopicCount);
        tvAlgorithms = findViewById(R.id.tvAlgorithms);
        tvDataStructures = findViewById(R.id.tvDataStructures);
        tvWebDevelopment = findViewById(R.id.tvWebDevelopment);
        tvTesting = findViewById(R.id.tvTesting);
        tvAndroid = findViewById(R.id.tvAndroid);
        btnNextToTasks = findViewById(R.id.btnNextToTasks);

        topicMap.put(tvAlgorithms, "Algorithms");
        topicMap.put(tvDataStructures, "Data Structures");
        topicMap.put(tvWebDevelopment, "Web Development");
        topicMap.put(tvTesting, "Testing");
        topicMap.put(tvAndroid, "Android");

        updateTopicCount();

        for (Map.Entry<TextView, String> entry : topicMap.entrySet()) {
            setupSelectableTopic(entry.getKey(), entry.getValue());
        }

        btnNextToTasks.setOnClickListener(v -> {
            if (selectedInterests.isEmpty()) {
                Toast.makeText(this, "Please select at least one topic", Toast.LENGTH_SHORT).show();
                return;
            }

            String username = getIntent().getStringExtra("username");

            Intent intent = new Intent(InterestsActivity.this, TaskListActivity.class);
            intent.putExtra("username", username);
            intent.putStringArrayListExtra("interests", new ArrayList<>(selectedInterests));
            startActivity(intent);
        });
    }

    private void updateTopicCount() {
        int count = topicMap.size();
        tvTopicCount.setText(count + " Topics Available");
    }

    private void setupSelectableTopic(TextView topicView, String topicName) {
        topicView.setOnClickListener(v -> {
            if (selectedInterests.contains(topicName)) {
                selectedInterests.remove(topicName);
                topicView.setBackgroundResource(R.drawable.topic_unselected);
            } else {
                selectedInterests.add(topicName);
                topicView.setBackgroundResource(R.drawable.topic_selected);
            }
        });
    }
}