package com.example.llm_learning_assistant.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

public class MainActivity extends AppCompatActivity {

    private Button btnGoLogin;
    private Button btnGoSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGoLogin = findViewById(R.id.btnGoLogin);
        btnGoSignup = findViewById(R.id.btnGoSignup);

        btnGoLogin.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, LoginActivity.class)));

        btnGoSignup.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SignupActivity.class)));
    }
}