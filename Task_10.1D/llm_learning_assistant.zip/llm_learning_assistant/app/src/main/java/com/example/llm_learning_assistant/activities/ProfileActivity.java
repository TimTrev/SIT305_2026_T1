package com.example.llm_learning_assistant.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvProfileUsername, tvProfileEmail, tvTotalQuestions, tvCorrectAnswers, tvIncorrectAnswers;
    private TextView tvProfileNotification;
    private Button btnBackProfile, btnShareProfile, btnViewHistory, btnUpgradeAccount, btnResetProfile;

    private String username;
    private ArrayList<String> interests;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvProfileUsername = findViewById(R.id.tvProfileUsername);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);
        tvTotalQuestions = findViewById(R.id.tvTotalQuestions);
        tvCorrectAnswers = findViewById(R.id.tvCorrectAnswers);
        tvIncorrectAnswers = findViewById(R.id.tvIncorrectAnswers);
        tvProfileNotification = findViewById(R.id.tvProfileNotification);

        btnBackProfile = findViewById(R.id.btnBackProfile);
        btnShareProfile = findViewById(R.id.btnShareProfile);
        btnViewHistory = findViewById(R.id.btnViewHistory);
        btnUpgradeAccount = findViewById(R.id.btnUpgradeAccount);
        btnResetProfile = findViewById(R.id.btnResetProfile);
        btnResetProfile.setOnClickListener(v -> showResetConfirmation());

        username = getIntent().getStringExtra("username");
        interests = getIntent().getStringArrayListExtra("interests");

        if (username == null || username.isEmpty()) {
            username = "Username";
        }

        if (interests == null) {
            interests = new ArrayList<>();
        }

        tvProfileEmail.setText(username.toLowerCase().replace(" ", "") + "@example.com");

        refreshProfileData();

        btnBackProfile.setOnClickListener(v -> finish());

        btnShareProfile.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);

            int total = prefs.getInt("total_questions", 0);
            int correct = prefs.getInt("correct_answers", 0);
            int incorrect = Math.max(0, total - correct);
            String accountType = prefs.getString("account_type", "Basic");

            shareProfile(total, correct, incorrect, accountType);
        });

        btnViewHistory.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, HistoryActivity.class);
            intent.putExtra("username", username);
            intent.putStringArrayListExtra("interests", interests);
            startActivity(intent);
        });

        btnUpgradeAccount.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, UpgradeActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshProfileData();
    }

    private void refreshProfileData() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);

        int total = prefs.getInt("total_questions", 0);
        int correct = prefs.getInt("correct_answers", 0);
        int incorrect = Math.max(0, total - correct);
        String accountType = prefs.getString("account_type", "Basic");

        tvProfileUsername.setText(username + " (" + accountType + ")");
        tvTotalQuestions.setText("Total\nQuestions\n" + total);
        tvCorrectAnswers.setText("Correctly\nAnswered\n" + correct);
        tvIncorrectAnswers.setText("Incorrect Answers\n" + incorrect);

        updateNotification();
    }

    private void updateNotification() {
        int tasksDue = interests.size();

        if (tasksDue > 0) {
            tvProfileNotification.setText("You have " + tasksDue + " task" + (tasksDue == 1 ? "" : "s") + " waiting to be completed.");
        } else {
            tvProfileNotification.setText("No new notifications.");
        }
    }

    private void shareProfile(int total, int correct, int incorrect, String accountType) {
        String shareText =
                "LLM Learning Assistant Profile\n\n" +
                        "Username: " + username + "\n" +
                        "Account Type: " + accountType + "\n" +
                        "Tasks Due: " + interests.size() + "\n" +
                        "Total Questions: " + total + "\n" +
                        "Correct Answers: " + correct + "\n" +
                        "Incorrect Answers: " + incorrect + "\n\n" +
                        "Shared from my LLM Learning Assistant app.";

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My Learning Profile");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

        startActivity(Intent.createChooser(shareIntent, "Share Profile"));
    }

    private void showResetConfirmation() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Reset Profile")
                .setMessage("This will reset your quiz history, account upgrade, statistics, and progress.\n\nYour current username will remain unchanged.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (dialog, which) -> resetProfileData())
                .show();
    }

    private void resetProfileData() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);

        prefs.edit()
                .clear()
                .apply();

        refreshProfileData();

        android.widget.Toast.makeText(this, "Profile progress has been reset", android.widget.Toast.LENGTH_SHORT).show();
    }
}