package com.example.llm_learning_assistant.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;
import com.example.llm_learning_assistant.helper.LlmHelper;
import com.example.llm_learning_assistant.model.Question;

import java.util.ArrayList;

public class ResultsActivity extends AppCompatActivity {

    private TextView tvResultsTitle;
    private LinearLayout layoutResultsCards;
    private Button btnContinue;

    private ArrayList<Question> questions;
    private ArrayList<String> interests;
    private String topic;
    private String username;
    private int taskNumber;
    private boolean hintUsed;

    private LlmHelper llmHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        tvResultsTitle = findViewById(R.id.tvResultsTitle);
        layoutResultsCards = findViewById(R.id.layoutResultsCards);
        btnContinue = findViewById(R.id.btnContinue);

        llmHelper = new LlmHelper();

        username = getIntent().getStringExtra("username");
        topic = getIntent().getStringExtra("topic");
        taskNumber = getIntent().getIntExtra("taskNumber", 1);
        interests = getIntent().getStringArrayListExtra("interests");
        questions = (ArrayList<Question>) getIntent().getSerializableExtra("questions");
        hintUsed = getIntent().getBooleanExtra("hintUsed", false);

        tvResultsTitle.setText("Your Results");

        buildResultCards();
        saveQuizHistory();
        removeCompletedTask();

        btnContinue.setOnClickListener(v -> {
            Intent intent = new Intent(ResultsActivity.this, TaskListActivity.class);
            intent.putExtra("username", username);
            intent.putStringArrayListExtra("interests", interests);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }

    private String getAccountType() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        return prefs.getString("account_type", "Basic");
    }

    private boolean canReviewAnswers() {
        String accountType = getAccountType();
        return accountType.equals("Starter") || accountType.equals("Intermediate") || accountType.equals("Advanced");
    }

    private boolean canUseFlashcards() {
        String accountType = getAccountType();
        return accountType.equals("Advanced");
    }

    private void buildResultCards() {
        layoutResultsCards.removeAllViews();

        if (questions == null) return;

        for (int i = 0; i < questions.size(); i++) {
            final Question question = questions.get(i);
            final int questionNumber = i + 1;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(24, 20, 24, 20);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.bottomMargin = 20;
            card.setLayoutParams(params);
            card.setBackgroundResource(R.drawable.blue_card);
            card.setClickable(true);

            TextView title = new TextView(this);
            title.setText(questionNumber + ". Question " + questionNumber);
            title.setTextColor(getColor(android.R.color.white));
            title.setTextSize(18f);
            title.setTypeface(null, Typeface.BOLD);

            TextView body = new TextView(this);
            body.setText(question.isCorrect()
                    ? "Correct answer selected"
                    : "Tap to review this answer or create flashcards");
            body.setTextColor(getColor(android.R.color.white));
            body.setTextSize(15f);
            body.setPadding(0, 10, 0, 0);

            card.addView(title);
            card.addView(body);

            card.setOnClickListener(v -> showPromptOptions(question, questionNumber));

            layoutResultsCards.addView(card);
        }
    }

    private void showPromptOptions(Question question, int questionNumber) {
        if (!canReviewAnswers()) {
            new AlertDialog.Builder(this)
                    .setTitle("Review Locked")
                    .setMessage("Basic accounts cannot review detailed answers.\n\nUpgrade to Starter or above to unlock answer review.")
                    .setPositiveButton("Upgrade", (dialog, which) -> {
                        Intent intent = new Intent(ResultsActivity.this, UpgradeActivity.class);
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }

        String[] options;

        if (canUseFlashcards()) {
            options = new String[]{"Review Answer", "Create Flashcards"};
        } else {
            options = new String[]{"Review Answer", "Flashcards Locked"};
        }

        new AlertDialog.Builder(this)
                .setTitle("Question " + questionNumber)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        explainAnswer(question, questionNumber);
                    } else {
                        if (canUseFlashcards()) {
                            createFlashcards(questionNumber);
                        } else {
                            new AlertDialog.Builder(this)
                                    .setTitle("Flashcards Locked")
                                    .setMessage("Flashcards require an Advanced account.")
                                    .setPositiveButton("OK", null)
                                    .show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveQuizHistory() {
        if (questions == null) return;

        int correct = 0;

        for (Question q : questions) {
            if (q.isCorrect()) correct++;
        }

        int total = questions.size();

        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        int currentTotal = prefs.getInt("total_questions", 0);
        int currentCorrect = prefs.getInt("correct_answers", 0);
        int historyCount = prefs.getInt("history_count", 0) + 1;

        SharedPreferences.Editor editor = prefs.edit();

        editor.putInt("total_questions", currentTotal + total);
        editor.putInt("correct_answers", currentCorrect + correct);
        editor.putInt("history_count", historyCount);
        editor.putString("history_topic_" + historyCount, topic);
        editor.putInt("history_score_" + historyCount, correct);
        editor.putInt("history_total_" + historyCount, total);
        editor.putBoolean("history_hint_used_" + historyCount, hintUsed);

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            int questionNumber = i + 1;

            editor.putString("history_" + historyCount + "_question_" + questionNumber, q.getQuestionText());
            editor.putString("history_" + historyCount + "_selected_" + questionNumber, q.getSelectedAnswerText());
            editor.putString("history_" + historyCount + "_correct_" + questionNumber, q.getCorrectAnswerText());
            editor.putBoolean("history_" + historyCount + "_is_correct_" + questionNumber, q.isCorrect());
        }

        editor.apply();
    }

    private void removeCompletedTask() {
        if (interests != null && topic != null) {
            interests.remove(topic);
        }
    }

    private void explainAnswer(Question question, int questionNumber) {
        AlertDialog loadingDialog = new AlertDialog.Builder(this)
                .setTitle("Explaining Answer")
                .setMessage("Please wait...")
                .setCancelable(false)
                .create();

        loadingDialog.show();

        llmHelper.explainAnswer(question, new LlmHelper.LlmCallback() {
            @Override
            public void onSuccess(String prompt, String response) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(ResultsActivity.this)
                        .setTitle("Question " + questionNumber + " Explanation")
                        .setMessage("Selected Answer: " + question.getSelectedAnswerText()
                                + "\nCorrect Answer: " + question.getCorrectAnswerText()
                                + "\n\nPrompt:\n" + prompt
                                + "\n\nResponse:\n" + response)
                        .setPositiveButton("OK", null)
                        .show();
            }

            @Override
            public void onError(String prompt, String errorMessage) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(ResultsActivity.this)
                        .setTitle("Error")
                        .setMessage("Prompt:\n" + prompt + "\n\nError:\n" + errorMessage)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    private void createFlashcards(int questionNumber) {
        AlertDialog loadingDialog = new AlertDialog.Builder(this)
                .setTitle("Creating Flashcards")
                .setMessage("Please wait...")
                .setCancelable(false)
                .create();

        loadingDialog.show();

        llmHelper.createFlashcards(topic, new LlmHelper.LlmCallback() {
            @Override
            public void onSuccess(String prompt, String response) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(ResultsActivity.this)
                        .setTitle("Question " + questionNumber + " Flashcards")
                        .setMessage("Prompt:\n" + prompt + "\n\nResponse:\n" + response)
                        .setPositiveButton("OK", null)
                        .show();
            }

            @Override
            public void onError(String prompt, String errorMessage) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(ResultsActivity.this)
                        .setTitle("Error")
                        .setMessage("Prompt:\n" + prompt + "\n\nError:\n" + errorMessage)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }
}