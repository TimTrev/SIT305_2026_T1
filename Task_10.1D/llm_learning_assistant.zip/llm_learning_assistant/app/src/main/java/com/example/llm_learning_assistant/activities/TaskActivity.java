package com.example.llm_learning_assistant.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;
import com.example.llm_learning_assistant.helper.DummyDataProvider;
import com.example.llm_learning_assistant.helper.LlmHelper;
import com.example.llm_learning_assistant.model.Question;

import java.util.ArrayList;

public class TaskActivity extends AppCompatActivity {

    private TextView tvTaskTitle, tvTaskSubtitle, tvQuestion;
    private RadioGroup rgQuestion;
    private RadioButton rbA, rbB, rbC, rbD;
    private Button btnGenerateHint, btnNextQuestion, btnSubmitTask;

    private ArrayList<Question> questions;
    private ArrayList<String> interests;
    private String topic;
    private String username;
    private int taskNumber;
    private int currentQuestionIndex = 0;

    private boolean hintUsed = false;
    private LlmHelper llmHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        tvTaskTitle = findViewById(R.id.tvTaskTitle);
        tvTaskSubtitle = findViewById(R.id.tvTaskSubtitle);
        tvQuestion = findViewById(R.id.tvQuestion);

        rgQuestion = findViewById(R.id.rgQuestion);
        rbA = findViewById(R.id.rbA);
        rbB = findViewById(R.id.rbB);
        rbC = findViewById(R.id.rbC);
        rbD = findViewById(R.id.rbD);

        btnGenerateHint = findViewById(R.id.btnGenerateHint);
        btnNextQuestion = findViewById(R.id.btnNextQuestion);
        btnSubmitTask = findViewById(R.id.btnSubmitTask);

        llmHelper = new LlmHelper();

        username = getIntent().getStringExtra("username");
        topic = getIntent().getStringExtra("topic");
        taskNumber = getIntent().getIntExtra("taskNumber", 1);
        interests = getIntent().getStringArrayListExtra("interests");

        questions = DummyDataProvider.getQuestionsForTopic(topic);

        tvTaskTitle.setText("Generated Task " + taskNumber);
        tvTaskSubtitle.setText(topic);

        setupHintAccess();
        showQuestion();

        btnGenerateHint.setOnClickListener(v -> showHintForCurrentQuestion());
        btnNextQuestion.setOnClickListener(v -> moveToNextQuestion());
        btnSubmitTask.setOnClickListener(v -> submitTask());
    }

    private void setupHintAccess() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        String accountType = prefs.getString("account_type", "Basic");

        if (accountType.equals("Basic")) {
            btnGenerateHint.setText("Hint Locked - Upgrade Required");
        }
    }

    private boolean canUseHints() {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        String accountType = prefs.getString("account_type", "Basic");
        return accountType.equals("Starter") || accountType.equals("Intermediate") || accountType.equals("Advanced");
    }

    private void showQuestion() {
        Question question = questions.get(currentQuestionIndex);

        tvQuestion.setText((currentQuestionIndex + 1) + ". " + question.getQuestionText());

        rbA.setText(question.getOptions().get(0));
        rbB.setText(question.getOptions().get(1));
        rbC.setText(question.getOptions().get(2));
        rbD.setText(question.getOptions().get(3));

        rgQuestion.clearCheck();

        if (question.getSelectedIndex() == 0) rbA.setChecked(true);
        if (question.getSelectedIndex() == 1) rbB.setChecked(true);
        if (question.getSelectedIndex() == 2) rbC.setChecked(true);
        if (question.getSelectedIndex() == 3) rbD.setChecked(true);

        boolean isLastQuestion = currentQuestionIndex == questions.size() - 1;
        btnNextQuestion.setVisibility(isLastQuestion ? View.GONE : View.VISIBLE);
        btnSubmitTask.setVisibility(isLastQuestion ? View.VISIBLE : View.GONE);
    }

    private void saveCurrentAnswer() {
        int checkedId = rgQuestion.getCheckedRadioButtonId();
        if (checkedId == -1) return;

        int selectedIndex = -1;
        if (checkedId == R.id.rbA) selectedIndex = 0;
        if (checkedId == R.id.rbB) selectedIndex = 1;
        if (checkedId == R.id.rbC) selectedIndex = 2;
        if (checkedId == R.id.rbD) selectedIndex = 3;

        questions.get(currentQuestionIndex).setSelectedIndex(selectedIndex);
    }

    private void moveToNextQuestion() {
        if (rgQuestion.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please choose an answer first", Toast.LENGTH_SHORT).show();
            return;
        }

        saveCurrentAnswer();

        if (currentQuestionIndex < questions.size() - 1) {
            currentQuestionIndex++;
            showQuestion();
        }
    }

    private void submitTask() {
        if (rgQuestion.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please choose an answer first", Toast.LENGTH_SHORT).show();
            return;
        }

        saveCurrentAnswer();

        Intent intent = new Intent(TaskActivity.this, ResultsActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("topic", topic);
        intent.putExtra("taskNumber", taskNumber);
        intent.putExtra("questions", questions);
        intent.putExtra("hintUsed", hintUsed);
        intent.putStringArrayListExtra("interests", interests);
        startActivity(intent);
    }

    private void showHintForCurrentQuestion() {
        if (!canUseHints()) {
            new AlertDialog.Builder(this)
                    .setTitle("Hint Locked")
                    .setMessage("Basic accounts cannot use AI-generated hints.\n\nUpgrade to Starter or above to unlock hints.")
                    .setPositiveButton("Upgrade", (dialog, which) -> {
                        Intent intent = new Intent(TaskActivity.this, UpgradeActivity.class);
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }

        hintUsed = true;

        Question question = questions.get(currentQuestionIndex);

        AlertDialog loadingDialog = new AlertDialog.Builder(this)
                .setTitle("Generating Hint")
                .setMessage("Please wait...")
                .setCancelable(false)
                .create();

        loadingDialog.show();

        llmHelper.generateHint(question, new LlmHelper.LlmCallback() {
            @Override
            public void onSuccess(String prompt, String response) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(TaskActivity.this)
                        .setTitle("Hint for Question " + (currentQuestionIndex + 1))
                        .setMessage("Prompt:\n" + prompt + "\n\nResponse:\n" + response)
                        .setPositiveButton("OK", null)
                        .show();
            }

            @Override
            public void onError(String prompt, String errorMessage) {
                loadingDialog.dismiss();
                new AlertDialog.Builder(TaskActivity.this)
                        .setTitle("Hint Error")
                        .setMessage("Prompt:\n" + prompt + "\n\nError:\n" + errorMessage)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }
}