package com.example.llm_learning_assistant.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

import java.util.ArrayList;

public class TaskListActivity extends AppCompatActivity {

    private TextView tvGreeting, tvTasksDue;
    private LinearLayout layoutTasks;
    private Button btnOpenProfile;

    private ArrayList<String> interests;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        tvGreeting = findViewById(R.id.tvGreeting);
        tvTasksDue = findViewById(R.id.tvTasksDue);
        layoutTasks = findViewById(R.id.layoutTasks);
        btnOpenProfile = findViewById(R.id.btnOpenProfile);

        username = getIntent().getStringExtra("username");
        interests = getIntent().getStringArrayListExtra("interests");

        if (interests == null) interests = new ArrayList<>();

        tvGreeting.setText("Hello,\n" + (username == null ? "Your Name" : username));
        tvTasksDue.setText("You have " + interests.size() + " task" + (interests.size() == 1 ? "" : "s") + " due");

        btnOpenProfile.setOnClickListener(v -> {
            Intent intent = new Intent(TaskListActivity.this, ProfileActivity.class);
            intent.putExtra("username", username);
            intent.putStringArrayListExtra("interests", interests);
            startActivity(intent);
        });

        buildTaskCards();
    }

    private void buildTaskCards() {
        layoutTasks.removeAllViews();

        for (int i = 0; i < interests.size(); i++) {
            final int taskNumber = i + 1;
            final String topic = interests.get(i);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(28, 24, 28, 24);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            cardParams.bottomMargin = 24;
            card.setLayoutParams(cardParams);
            card.setBackgroundResource(R.drawable.blue_card);

            TextView title = new TextView(this);
            title.setText("Generated Task " + taskNumber);
            title.setTextSize(20f);
            title.setTextColor(getColor(android.R.color.white));
            title.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView desc = new TextView(this);
            desc.setText("Task " + taskNumber + " - " + topic);
            desc.setTextSize(16f);
            desc.setTextColor(getColor(android.R.color.white));
            desc.setPadding(0, 12, 0, 18);

            Button openTask = new Button(this);
            openTask.setText("Open Task");
            openTask.setTextColor(getColor(android.R.color.black));
            openTask.setBackgroundResource(R.drawable.green_button);

            openTask.setOnClickListener(v -> {
                Intent intent = new Intent(TaskListActivity.this, TaskActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("topic", topic);
                intent.putExtra("taskNumber", taskNumber);
                intent.putStringArrayListExtra("interests", interests);
                startActivity(intent);
            });

            card.addView(title);
            card.addView(desc);
            card.addView(openTask);

            layoutTasks.addView(card);
        }
    }
}