package com.example.llm_learning_assistant.activities;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.llm_learning_assistant.R;

public class UpgradeActivity extends AppCompatActivity {

    private Button btnBackUpgrade;
    private Button btnPurchaseStarter;
    private Button btnPurchaseIntermediate;
    private Button btnPurchaseAdvanced;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upgrade);

        // Link XML views
        btnBackUpgrade = findViewById(R.id.btnBackUpgrade);
        btnPurchaseStarter = findViewById(R.id.btnPurchaseStarter);
        btnPurchaseIntermediate = findViewById(R.id.btnPurchaseIntermediate);
        btnPurchaseAdvanced = findViewById(R.id.btnPurchaseAdvanced);

        // Back button
        btnBackUpgrade.setOnClickListener(v -> finish());

        // Purchase buttons
        btnPurchaseStarter.setOnClickListener(v -> showPurchaseDialog("Starter"));
        btnPurchaseIntermediate.setOnClickListener(v -> showPurchaseDialog("Intermediate"));
        btnPurchaseAdvanced.setOnClickListener(v -> showPurchaseDialog("Advanced"));
    }

    /**
     * Shows the first purchase dialog with:
     * - Cancel
     * - Purchase with Google Pay
     * - Confirm
     */
    private void showPurchaseDialog(String planName) {
        new AlertDialog.Builder(this)
                .setTitle("Purchase")
                .setMessage(
                        "Selected plan: " + planName + "\n\n" +
                                "Choose a payment option below."
                )
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Purchase with Google Pay", (dialog, which) ->
                        showMockGooglePayDialog(planName))
                .setPositiveButton("Confirm", (dialog, which) ->
                        activatePlan(planName))
                .show();
    }

    /**
     * Shows a simulated Google Pay checkout screen.
     * This does not connect to any real Google account or bank account.
     */
    private void showMockGooglePayDialog(String planName) {
        new AlertDialog.Builder(this)
                .setTitle("G Pay")
                .setMessage(
                        "Google Pay Test Mode\n\n" +
                                "Plan: " + planName + "\n" +
                                "Amount: " + getPlanPrice(planName) + "\n\n" +
                                "This is a simulated Google Pay checkout for demonstration purposes only.\n" +
                                "No real Google account, credit card, or bank account is connected."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Confirm Test Payment", (dialog, which) ->
                        activatePlan(planName))
                .show();
    }

    /**
     * Returns the displayed price for each plan.
     */
    private String getPlanPrice(String planName) {
        switch (planName) {
            case "Starter":
                return "$4.99 AUD";
            case "Intermediate":
                return "$7.99 AUD";
            case "Advanced":
                return "$9.99 AUD";
            default:
                return "$0.00 AUD";
        }
    }

    /**
     * Saves the selected account type locally and closes the screen.
     */
    private void activatePlan(String planName) {
        SharedPreferences prefs = getSharedPreferences("learning_stats", MODE_PRIVATE);
        prefs.edit()
                .putString("account_type", planName)
                .apply();

        Toast.makeText(this, planName + " plan activated successfully", Toast.LENGTH_SHORT).show();

        // Close Upgrade screen and return to Profile
        finish();
    }
}