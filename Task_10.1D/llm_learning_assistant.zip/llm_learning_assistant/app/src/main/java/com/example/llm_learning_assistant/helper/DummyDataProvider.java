package com.example.llm_learning_assistant.helper;

import com.example.llm_learning_assistant.model.Question;

import java.util.ArrayList;
import java.util.Arrays;

public class DummyDataProvider {

    public static ArrayList<Question> getQuestionsForTopic(String topic) {
        ArrayList<Question> questions = new ArrayList<>();

        if (topic == null) {
            topic = "Algorithms";
        }

        switch (topic.toLowerCase()) {
            case "data structures":
                questions.add(new Question(
                        "Which data structure follows FIFO order?",
                        new ArrayList<>(Arrays.asList("Stack", "Queue", "Tree", "Graph")),
                        1
                ));
                questions.add(new Question(
                        "Which data structure stores key-value pairs?",
                        new ArrayList<>(Arrays.asList("Array", "HashMap", "Queue", "Linked List")),
                        1
                ));
                questions.add(new Question(
                        "Which data structure is best for LIFO access?",
                        new ArrayList<>(Arrays.asList("Queue", "Heap", "Stack", "Graph")),
                        2
                ));
                break;

            case "web development":
                questions.add(new Question(
                        "Which language is mainly used to structure web pages?",
                        new ArrayList<>(Arrays.asList("CSS", "JavaScript", "HTML", "SQL")),
                        2
                ));
                questions.add(new Question(
                        "Which language is primarily used for styling web pages?",
                        new ArrayList<>(Arrays.asList("CSS", "Python", "Java", "C++")),
                        0
                ));
                questions.add(new Question(
                        "Which of these runs in the browser?",
                        new ArrayList<>(Arrays.asList("JavaScript", "MySQL", "Flask", "SQLite")),
                        0
                ));
                break;

            case "android":
                questions.add(new Question(
                        "What file is commonly used to design Android screen layouts?",
                        new ArrayList<>(Arrays.asList(".java", ".xml", ".gradle", ".json")),
                        1
                ));
                questions.add(new Question(
                        "Which component usually represents one Android screen?",
                        new ArrayList<>(Arrays.asList("Activity", "Service", "BroadcastReceiver", "Provider")),
                        0
                ));
                questions.add(new Question(
                        "Where do you usually declare app permissions?",
                        new ArrayList<>(Arrays.asList("styles.xml", "AndroidManifest.xml", "strings.xml", "build.gradle")),
                        1
                ));
                break;

            case "testing":
                questions.add(new Question(
                        "What is the purpose of testing software?",
                        new ArrayList<>(Arrays.asList(
                                "To find and reduce defects",
                                "To make apps slower",
                                "To remove all documentation",
                                "To replace users"
                        )),
                        0
                ));
                questions.add(new Question(
                        "Which test checks small parts of code individually?",
                        new ArrayList<>(Arrays.asList("System test", "Acceptance test", "Unit test", "Stress test")),
                        2
                ));
                questions.add(new Question(
                        "What does regression testing help detect?",
                        new ArrayList<>(Arrays.asList(
                                "New bugs introduced after changes",
                                "Internet speed issues only",
                                "Battery level problems only",
                                "Screen brightness issues only"
                        )),
                        0
                ));
                break;

            default:
                questions.add(new Question(
                        "What is an algorithm?",
                        new ArrayList<>(Arrays.asList(
                                "A step-by-step procedure for solving a problem",
                                "A type of monitor",
                                "A mobile phone setting",
                                "A database table"
                        )),
                        0
                ));
                questions.add(new Question(
                        "What is the main goal of a sorting algorithm?",
                        new ArrayList<>(Arrays.asList(
                                "To encrypt files",
                                "To arrange data in order",
                                "To delete duplicates only",
                                "To connect to the internet"
                        )),
                        1
                ));
                questions.add(new Question(
                        "Binary search works best on:",
                        new ArrayList<>(Arrays.asList(
                                "Unsorted arrays",
                                "Sorted data",
                                "Images",
                                "Audio files"
                        )),
                        1
                ));
                break;
        }

        return questions;
    }
}