package com.example.llm_learning_assistant.helper;

import com.example.llm_learning_assistant.model.GeminiRequest;
import com.example.llm_learning_assistant.model.GeminiResponse;
import com.example.llm_learning_assistant.model.Question;
import com.example.llm_learning_assistant.network.GeminiApiService;
import com.example.llm_learning_assistant.network.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LlmHelper {

    public interface LlmCallback {
        void onSuccess(String prompt, String response);
        void onError(String prompt, String errorMessage);
    }

    private final GeminiApiService geminiApiService;

    public LlmHelper() {
        geminiApiService = RetrofitClient
                .getGeminiClient()
                .create(GeminiApiService.class);
    }

    public void generateHint(Question question, LlmCallback callback) {
        String prompt = "Give a short learning hint for this multiple-choice question without revealing the answer.\n\n"
                + "Question: " + question.getQuestionText() + "\n"
                + "Options:\n"
                + "A. " + question.getOptions().get(0) + "\n"
                + "B. " + question.getOptions().get(1) + "\n"
                + "C. " + question.getOptions().get(2) + "\n"
                + "D. " + question.getOptions().get(3);

        sendPrompt(prompt, callback);
    }

    public void explainAnswer(Question question, LlmCallback callback) {
        String prompt = "Explain why the correct answer is right and whether the student's selected answer is correct or incorrect. "
                + "Keep it short and student-friendly.\n\n"
                + "Question: " + question.getQuestionText() + "\n"
                + "Student answer: " + question.getSelectedAnswerText() + "\n"
                + "Correct answer: " + question.getCorrectAnswerText();

        sendPrompt(prompt, callback);
    }

    public void createFlashcards(String topic, LlmCallback callback) {
        String prompt = "Create 3 short flashcards for a beginner studying this topic: " + topic
                + ". Format them clearly as Question and Answer.";

        sendPrompt(prompt, callback);
    }

    // ============ NOTE: Replace " YOUR_GEMINI_API_KEY_HERE " with your Gemini API key ============
    //String apiKey = "YOUR_GEMINI_API_KEY_HERE";
    private void sendPrompt(String prompt, LlmCallback callback) {
        String apiKey = "YOUR_GEMINI_API_KEY_HERE";

        if (apiKey == null || apiKey.trim().isEmpty()) {
            callback.onError(prompt, "Gemini API key is missing.");
            return;
        }

        GeminiRequest request = new GeminiRequest(prompt);

        geminiApiService.generateContent(apiKey, request)
                .enqueue(new Callback<GeminiResponse>() {
                    @Override
                    public void onResponse(Call<GeminiResponse> call, Response<GeminiResponse> response) {
                        if (!response.isSuccessful()) {
                            callback.onError(prompt, "Gemini request failed with HTTP " + response.code());
                            return;
                        }

                        GeminiResponse body = response.body();
                        if (body == null) {
                            callback.onError(prompt, "Gemini returned an empty response.");
                            return;
                        }

                        String text = body.extractText();
                        if (text == null || text.trim().isEmpty()) {
                            callback.onError(prompt, "Gemini returned no usable text.");
                            return;
                        }

                        callback.onSuccess(prompt, text.trim());
                    }

                    @Override
                    public void onFailure(Call<GeminiResponse> call, Throwable t) {
                        callback.onError(prompt, "Network error: " + t.getMessage());
                    }
                });
    }
}