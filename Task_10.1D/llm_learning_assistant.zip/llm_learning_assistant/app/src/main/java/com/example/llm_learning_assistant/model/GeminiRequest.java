package com.example.llm_learning_assistant.model;

import java.util.ArrayList;
import java.util.List;

public class GeminiRequest {

    private List<Content> contents;

    public GeminiRequest(String prompt) {
        this.contents = new ArrayList<>();
        this.contents.add(new Content(prompt));
    }

    public static class Content {
        private List<Part> parts;

        public Content(String text) {
            this.parts = new ArrayList<>();
            this.parts.add(new Part(text));
        }
    }

    public static class Part {
        private String text;

        public Part(String text) {
            this.text = text;
        }
    }
}