package com.example.llm_learning_assistant.model;

import java.util.List;

public class GeminiResponse {

    private List<Candidate> candidates;

    public String extractText() {
        if (candidates == null || candidates.isEmpty()) return null;
        Candidate candidate = candidates.get(0);
        if (candidate.content == null || candidate.content.parts == null || candidate.content.parts.isEmpty()) {
            return null;
        }
        return candidate.content.parts.get(0).text;
    }

    public static class Candidate {
        public Content content;
    }

    public static class Content {
        public List<Part> parts;
    }

    public static class Part {
        public String text;
    }
}