package com.example.llm_learning_assistant.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Question implements Serializable {
    private String questionText;
    private ArrayList<String> options;
    private int correctIndex;
    private int selectedIndex;

    public Question(String questionText, ArrayList<String> options, int correctIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctIndex = correctIndex;
        this.selectedIndex = -1;
    }

    public String getQuestionText() {
        return questionText;
    }

    public ArrayList<String> getOptions() {
        return options;
    }

    public int getCorrectIndex() {
        return correctIndex;
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    public void setSelectedIndex(int selectedIndex) {
        this.selectedIndex = selectedIndex;
    }

    public boolean isCorrect() {
        return selectedIndex == correctIndex;
    }

    public String getCorrectAnswerText() {
        if (correctIndex >= 0 && correctIndex < options.size()) {
            return options.get(correctIndex);
        }
        return "";
    }

    public String getSelectedAnswerText() {
        if (selectedIndex >= 0 && selectedIndex < options.size()) {
            return options.get(selectedIndex);
        }
        return "No answer selected";
    }
}