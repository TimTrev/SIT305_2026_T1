package com.example.llm_learning_assistant.model;

import java.util.ArrayList;

public class QuizResponse {
    private ArrayList<Question> quiz;

    public ArrayList<Question> getQuiz() {
        return quiz;
    }

    public void setQuiz(ArrayList<Question> quiz) {
        this.quiz = quiz;
    }
}