package com.example.llm_learning_assistant.model;

import java.io.Serializable;
import java.util.ArrayList;

public class UserProfile implements Serializable {
    private String username;
    private String email;
    private String phone;
    private ArrayList<String> interests;

    public UserProfile(String username, String email, String phone, ArrayList<String> interests) {
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.interests = interests;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public ArrayList<String> getInterests() {
        return interests;
    }
}