package com.example.llm_learning_assistant.network;

import com.example.llm_learning_assistant.model.GeminiRequest;
import com.example.llm_learning_assistant.model.GeminiResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface GeminiApiService {

    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    Call<GeminiResponse> generateContent(
            @Header("x-goog-api-key") String apiKey,
            @Body GeminiRequest request
    );
}