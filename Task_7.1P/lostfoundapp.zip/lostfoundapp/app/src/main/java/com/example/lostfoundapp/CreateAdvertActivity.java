package com.example.lostfoundapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CreateAdvertActivity extends AppCompatActivity {

    RadioGroup radioGroupPostType;
    RadioButton radioLost, radioFound;
    EditText edtName, edtPhone, edtDescription, edtDate, edtLocation;
    Spinner spinnerCategory;
    Button btnUploadImage, btnSave;
    ImageView imagePreview;

    DatabaseHelper databaseHelper;
    String selectedImageUri = "";

    ActivityResultLauncher<String> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_advert);

        databaseHelper = new DatabaseHelper(this);

        radioGroupPostType = findViewById(R.id.radioGroupPostType);
        radioLost = findViewById(R.id.radioLost);
        radioFound = findViewById(R.id.radioFound);
        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtDescription = findViewById(R.id.edtDescription);
        edtDate = findViewById(R.id.edtDate);
        edtLocation = findViewById(R.id.edtLocation);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnSave = findViewById(R.id.btnSave);
        imagePreview = findViewById(R.id.imagePreview);

        setupCategorySpinner();
        handlePrefilledFoundAdvert();
        setupDateTimeStamp();
        setupImagePicker();

        btnUploadImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        btnSave.setOnClickListener(v -> saveAdvert());
    }

    private void setupCategorySpinner() {
        String[] categories = {"Electronics", "Pets", "Wallets", "Keys", "Clothing", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                categories
        );
        spinnerCategory.setAdapter(adapter);
    }

    private void setupDateTimeStamp() {
        String currentDate = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());
        edtDate.setText(currentDate);
    }

    private void setupImagePicker() {
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri.toString();
                        imagePreview.setImageURI(uri);

                        try {
                            getContentResolver().takePersistableUriPermission(
                                    uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            );
                        } catch (Exception ignored) {
                        }
                    }
                }
        );
    }

    private void saveAdvert() {
        String postType = radioLost.isChecked() ? "Lost" : "Found";
        String name = edtName.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        String description = edtDescription.getText().toString().trim();
        String date = edtDate.getText().toString().trim();
        String location = edtLocation.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();

        if (name.isEmpty() || phone.isEmpty() || description.isEmpty()
                || date.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri.isEmpty()) {
            Toast.makeText(this, "Please upload an image", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = databaseHelper.insertItem(
                postType,
                name,
                phone,
                description,
                date,
                location,
                category,
                selectedImageUri
        );

        if (inserted) {
            Toast.makeText(this, "Advert saved successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(CreateAdvertActivity.this, ItemListActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to save advert", Toast.LENGTH_SHORT).show();
        }
    }
    private void handlePrefilledFoundAdvert() {
        String mode = getIntent().getStringExtra("mode");

        if (mode != null && mode.equals("found_from_lost")) {
            radioFound.setChecked(true);

            edtName.setText(getIntent().getStringExtra("name"));
            edtPhone.setText(getIntent().getStringExtra("phone"));
            edtDescription.setText(getIntent().getStringExtra("description"));
            edtLocation.setText(getIntent().getStringExtra("location"));

            String category = getIntent().getStringExtra("category");

            if (category != null) {
                for (int i = 0; i < spinnerCategory.getCount(); i++) {
                    if (spinnerCategory.getItemAtPosition(i).toString().equals(category)) {
                        spinnerCategory.setSelection(i);
                        break;
                    }
                }
            }

            Toast.makeText(this, "Found form pre-filled from lost advert", Toast.LENGTH_SHORT).show();
        }
    }
}