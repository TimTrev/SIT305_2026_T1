package com.example.lostfoundapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ItemAdapter extends BaseAdapter {

    private final Context context;
    private final ArrayList<LostFoundItem> items;
    private final DatabaseHelper databaseHelper;

    public ItemAdapter(Context context, ArrayList<LostFoundItem> items) {
        this.context = context;
        this.items = items;
        this.databaseHelper = new DatabaseHelper(context);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public LostFoundItem getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;

        if (row == null) {
            row = LayoutInflater.from(context).inflate(R.layout.item_advert_row, parent, false);
        }

        TextView txtRowTitle = row.findViewById(R.id.txtRowTitle);
        Button btnRowDelete = row.findViewById(R.id.btnRowDelete);

        LostFoundItem item = items.get(position);

        txtRowTitle.setText(item.getDescription());

        row.setOnClickListener(v -> {
            Intent intent = new Intent(context, ItemDetailActivity.class);
            intent.putExtra("itemId", item.getId());
            context.startActivity(intent);
        });

        btnRowDelete.setOnClickListener(v -> showDeleteDialog(item));

        return row;
    }

    private void showDeleteDialog(LostFoundItem item) {
        new AlertDialog.Builder(context)
                .setTitle("Delete advert")
                .setMessage("Are you sure you want to delete this advert?")
                .setPositiveButton("Delete", (dialog, which) -> deleteItem(item))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteItem(LostFoundItem item) {
        boolean deleted = databaseHelper.deleteItem(item.getId());

        if (deleted) {
            items.remove(item);
            notifyDataSetChanged();
            Toast.makeText(context, "Advert deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }
}