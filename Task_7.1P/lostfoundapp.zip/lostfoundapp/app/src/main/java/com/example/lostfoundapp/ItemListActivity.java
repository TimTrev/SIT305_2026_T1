package com.example.lostfoundapp;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ItemListActivity extends AppCompatActivity {

    Spinner spinnerFilter;
    ListView listViewItems;
    DatabaseHelper databaseHelper;
    ArrayList<Object> displayList = new ArrayList<>();
    SectionedItemAdapter sectionedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        spinnerFilter = findViewById(R.id.spinnerFilter);
        listViewItems = findViewById(R.id.listViewItems);
        databaseHelper = new DatabaseHelper(this);

        setupFilterSpinner();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (spinnerFilter.getSelectedItem() != null) {
            loadItems(spinnerFilter.getSelectedItem().toString());
        } else {
            loadItems("All");
        }
    }

    private void setupFilterSpinner() {
        String[] categories = {"All", "Electronics", "Pets", "Wallets", "Keys", "Clothing", "Other"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                categories
        );

        spinnerFilter.setAdapter(adapter);

        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                loadItems(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                loadItems("All");
            }
        });
    }

    private void loadItems(String category) {
        ArrayList<LostFoundItem> allItems = databaseHelper.getItemsByCategory(category);

        displayList.clear();

        boolean hasLost = false;
        boolean hasFound = false;

        for (LostFoundItem item : allItems) {
            if (item.getPostType().equalsIgnoreCase("Lost")) {
                hasLost = true;
                break;
            }
        }

        for (LostFoundItem item : allItems) {
            if (item.getPostType().equalsIgnoreCase("Found")) {
                hasFound = true;
                break;
            }
        }

        if (hasLost) {
            displayList.add("LOST ITEMS");

            for (LostFoundItem item : allItems) {
                if (item.getPostType().equalsIgnoreCase("Lost")) {
                    displayList.add(item);
                }
            }
        }

        if (hasFound) {
            displayList.add("FOUND ITEMS");

            for (LostFoundItem item : allItems) {
                if (item.getPostType().equalsIgnoreCase("Found")) {
                    displayList.add(item);
                }
            }
        }

        sectionedAdapter = new SectionedItemAdapter(this, displayList);
        listViewItems.setAdapter(sectionedAdapter);
    }
}