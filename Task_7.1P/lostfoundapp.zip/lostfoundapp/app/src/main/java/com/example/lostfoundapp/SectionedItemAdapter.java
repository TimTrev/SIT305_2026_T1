package com.example.lostfoundapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SectionedItemAdapter extends BaseAdapter {

    private final Context context;
    private final ArrayList<Object> displayList;
    private final DatabaseHelper databaseHelper;

    public SectionedItemAdapter(Context context, ArrayList<Object> displayList) {
        this.context = context;
        this.displayList = displayList;
        this.databaseHelper = new DatabaseHelper(context);
    }

    @Override
    public int getCount() {
        return displayList.size();
    }

    @Override
    public Object getItem(int position) {
        return displayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean isEnabled(int position) {
        return !(displayList.get(position) instanceof String);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Object rowItem = displayList.get(position);

        if (rowItem instanceof String) {
            TextView heading = new TextView(context);
            heading.setText((String) rowItem);
            heading.setTextSize(18);
            heading.setTypeface(null, Typeface.BOLD);
            heading.setPadding(20, 30, 20, 10);
            return heading;
        }

        LostFoundItem item = (LostFoundItem) rowItem;

        View row = LayoutInflater.from(context).inflate(R.layout.item_advert_row, parent, false);

        TextView txtRowTitle = row.findViewById(R.id.txtRowTitle);
        Button btnRowDelete = row.findViewById(R.id.btnRowDelete);

        txtRowTitle.setText(item.getDescription());

        row.setOnClickListener(v -> {
            Intent intent = new Intent(context, ItemDetailActivity.class);
            intent.putExtra("itemId", item.getId());
            context.startActivity(intent);
        });

        btnRowDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete advert")
                    .setMessage("Are you sure you want to delete this advert?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        boolean deleted = databaseHelper.deleteItem(item.getId());

                        if (deleted) {
                            displayList.remove(position);
                            notifyDataSetChanged();
                            Toast.makeText(context, "Advert deleted", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        return row;
    }
}