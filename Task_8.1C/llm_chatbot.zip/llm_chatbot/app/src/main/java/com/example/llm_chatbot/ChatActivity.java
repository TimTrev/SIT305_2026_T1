package com.example.llm_chatbot;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class ChatActivity extends Activity {

    RecyclerView recyclerMessages;
    EditText editMessage;
    Button btnSend;
    TextView btnHistory, txtChatTitle;

    ChatAdapter chatAdapter;
    List<Message> messages = new ArrayList<>();

    AppDatabase database;
    GeminiService geminiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        recyclerMessages = findViewById(R.id.recyclerMessages);
        editMessage = findViewById(R.id.editMessage);
        btnSend = findViewById(R.id.btnSend);
        btnHistory = findViewById(R.id.btnHistory);
        txtChatTitle = findViewById(R.id.txtChatTitle);

        String username = getIntent().getStringExtra("username");
        if (username != null && !username.isEmpty()) {
            txtChatTitle.setText("Welcome " + username);
        }

        database = Room.databaseBuilder(
                getApplicationContext(),
                AppDatabase.class,
                "chat_database"
        ).build();

        geminiService = new GeminiService();

        chatAdapter = new ChatAdapter(messages);
        recyclerMessages.setLayoutManager(new LinearLayoutManager(this));
        recyclerMessages.setAdapter(chatAdapter);

        loadChatHistory();

        btnSend.setOnClickListener(v -> sendUserMessage());
        btnHistory.setOnClickListener(v -> showHistoryDialog());
    }

    private void sendUserMessage() {
        String text = editMessage.getText().toString().trim();

        if (text.isEmpty()) {
            return;
        }

        editMessage.setText("");

        Message userMessage = new Message(text, true, getCurrentTime());
        addMessage(userMessage);

        geminiService.sendMessage(text, new GeminiService.GeminiCallback() {
            @Override
            public void onResponse(String reply) {
                runOnUiThread(() -> {
                    Message botMessage = new Message(reply, false, getCurrentTime());
                    addMessage(botMessage);
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Message errorMessage = new Message(error, false, getCurrentTime());
                    addMessage(errorMessage);
                });
            }
        });
    }

    private void addMessage(Message message) {
        messages.add(message);
        chatAdapter.notifyItemInserted(messages.size() - 1);
        recyclerMessages.scrollToPosition(messages.size() - 1);

        Executors.newSingleThreadExecutor().execute(() ->
                database.messageDao().insert(message)
        );
    }

    private void loadChatHistory() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Message> savedMessages = database.messageDao().getAllMessages();

            runOnUiThread(() -> {
                messages.clear();
                messages.addAll(savedMessages);

                if (messages.isEmpty()) {
                    messages.add(new Message("Welcome User!", false, getCurrentTime()));
                }

                chatAdapter.notifyDataSetChanged();
                recyclerMessages.scrollToPosition(messages.size() - 1);
            });
        });
    }

    private void showHistoryDialog() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Message> savedMessages = database.messageDao().getAllMessages();
            StringBuilder history = new StringBuilder();

            for (Message message : savedMessages) {
                history.append(message.isUser ? "User: " : "Bot: ")
                        .append(message.text)
                        .append("  [")
                        .append(message.timestamp)
                        .append("]\n\n");
            }

            if (history.length() == 0) {
                history.append("No chat history yet.");
            }

            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setTitle("Chat History")
                    .setMessage(history.toString())
                    .setPositiveButton("Close", null)
                    .setNegativeButton("Clear History", (dialog, which) -> clearHistory())
                    .show());
        });
    }

    private void clearHistory() {
        Executors.newSingleThreadExecutor().execute(() -> {
            database.messageDao().clearMessages();

            runOnUiThread(() -> {
                messages.clear();
                messages.add(new Message("Welcome User!", false, getCurrentTime()));
                chatAdapter.notifyDataSetChanged();
            });
        });
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
    }
}