package com.example.llm_chatbot;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

public class GeminiService {

    public interface GeminiCallback {
        void onResponse(String reply);
        void onError(String error);
    }

    // ########## NOTE: Replace "YOUR_GEMINI_API_KEY" with your actual Google Gemini API key ##########
    private static final String API_KEY = "YOUR_GEMINI_API";

    private static final String URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="
                    + API_KEY;

    private final OkHttpClient client = new OkHttpClient();

    public void sendMessage(String userMessage, GeminiCallback callback) {
        try {
            JSONObject textPart = new JSONObject();
            textPart.put("text", userMessage);

            JSONArray parts = new JSONArray();
            parts.put(textPart);

            JSONObject content = new JSONObject();
            content.put("parts", parts);

            JSONArray contents = new JSONArray();
            contents.put(content);

            JSONObject bodyJson = new JSONObject();
            bodyJson.put("contents", contents);

            RequestBody body = RequestBody.create(
                    bodyJson.toString(),
                    MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                    .url(URL)
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onError("Gemini request failed: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        callback.onError("Gemini error: " + response.code());
                        return;
                    }

                    String responseBody = response.body().string();

                    try {
                        JSONObject json = new JSONObject(responseBody);
                        String reply = json
                                .getJSONArray("candidates")
                                .getJSONObject(0)
                                .getJSONObject("content")
                                .getJSONArray("parts")
                                .getJSONObject(0)
                                .getString("text");

                        callback.onResponse(reply.trim());

                    } catch (Exception e) {
                        callback.onError("Could not read Gemini response.");
                    }
                }
            });

        } catch (Exception e) {
            callback.onError("Request error: " + e.getMessage());
        }
    }
}