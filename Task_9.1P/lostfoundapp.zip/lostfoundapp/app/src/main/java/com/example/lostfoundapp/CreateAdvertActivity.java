package com.example.lostfoundapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.common.api.Status;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;

import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CreateAdvertActivity extends AppCompatActivity {

    RadioGroup radioGroupPostType;
    RadioButton radioLost, radioFound;
    EditText edtName, edtPhone, edtDescription, edtDate, edtLocation;
    Spinner spinnerCategory;
    Button btnUploadImage, btnSave, btnCurrentLocation;
    ImageView imagePreview;

    DatabaseHelper databaseHelper;
    String selectedImageUri = "";

    double selectedLatitude = 0.0;
    double selectedLongitude = 0.0;
    boolean locationSelected = false;

    FusedLocationProviderClient fusedLocationClient;

    ActivityResultLauncher<String> imagePickerLauncher;
    ActivityResultLauncher<String> locationPermissionLauncher;
    ActivityResultLauncher<Intent> autocompleteLauncher;

    // ########## NOTE: Replace "YOUR_GOOGLE_CLOUD_API_KEY_HERE" with your actual Google Cloud API key ##########
    private static final String API_KEY = "YOUR_GOOGLE_CLOUD_API_KEY_HERE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_advert);

        databaseHelper = new DatabaseHelper(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), API_KEY);
        }

        radioGroupPostType = findViewById(R.id.radioGroupPostType);
        radioLost = findViewById(R.id.radioLost);
        radioFound = findViewById(R.id.radioFound);
        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtDescription = findViewById(R.id.edtDescription);
        edtDate = findViewById(R.id.edtDate);
        edtLocation = findViewById(R.id.edtLocation);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnSave = findViewById(R.id.btnSave);
        btnCurrentLocation = findViewById(R.id.btnCurrentLocation);
        imagePreview = findViewById(R.id.imagePreview);

        setupCategorySpinner();
        setupDateTimeStamp();
        setupImagePicker();
        setupLocationPermission();
        setupAutocomplete();

        handlePrefilledFoundAdvert();

        btnUploadImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        edtLocation.setOnClickListener(v -> openAutocomplete());

        btnCurrentLocation.setOnClickListener(v -> getCurrentLocation());

        btnSave.setOnClickListener(v -> saveAdvert());
    }

    private void setupCategorySpinner() {
        String[] categories = {"Electronics", "Pets", "Wallets", "Keys", "Clothing", "Other"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                categories
        );

        spinnerCategory.setAdapter(adapter);
    }

    private void setupDateTimeStamp() {
        String currentDate = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());
        edtDate.setText(currentDate);
    }

    private void setupImagePicker() {
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri.toString();
                        imagePreview.setImageURI(uri);

                        try {
                            getContentResolver().takePersistableUriPermission(
                                    uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            );
                        } catch (Exception ignored) {
                        }
                    }
                }
        );
    }

    private void setupLocationPermission() {
        locationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        getCurrentLocation();
                    } else {
                        Toast.makeText(this, "Location permission is required", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }



    private void setupAutocomplete() {
        autocompleteLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {

                        Place place = Autocomplete.getPlaceFromIntent(result.getData());

                        edtLocation.setText(place.getAddress());

                        if (place.getLatLng() != null) {
                            selectedLatitude = place.getLatLng().latitude;
                            selectedLongitude = place.getLatLng().longitude;
                            locationSelected = true;
                        }

                    } else if (result.getResultCode() == AutocompleteActivity.RESULT_ERROR
                            && result.getData() != null) {

                        Status status = Autocomplete.getStatusFromIntent(result.getData());

                        Toast.makeText(this,
                                "Autocomplete error: " + status.getStatusMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    private void openAutocomplete() {

        List<Place.Field> fields = Arrays.asList(
                Place.Field.ID,
                Place.Field.NAME,
                Place.Field.ADDRESS,
                Place.Field.LAT_LNG
        );

        Intent intent = new Autocomplete.IntentBuilder(
                com.google.android.libraries.places.widget.model.AutocompleteActivityMode.FULLSCREEN,
                fields
        ).build(this);

        autocompleteLauncher.launch(intent);
    }

    private void getCurrentLocation() {

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            locationPermissionLauncher.launch(
                    Manifest.permission.ACCESS_FINE_LOCATION);

            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(location -> {

                    if (location != null) {

                        selectedLatitude = location.getLatitude();
                        selectedLongitude = location.getLongitude();
                        locationSelected = true;

                        edtLocation.setText(
                                "Current location selected");

                        Toast.makeText(this,
                                "Current location selected",
                                Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(this,
                                "Could not get current location",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void saveAdvert() {

        String postType = radioLost.isChecked() ? "Lost" : "Found";

        String name = edtName.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        String description = edtDescription.getText().toString().trim();
        String date = edtDate.getText().toString().trim();
        String location = edtLocation.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();

        if (name.isEmpty() || phone.isEmpty()
                || description.isEmpty()
                || date.isEmpty()
                || location.isEmpty()) {

            Toast.makeText(this,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        if (!locationSelected) {

            Toast.makeText(this,
                    "Please choose a location",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        if (selectedImageUri.isEmpty()) {

            Toast.makeText(this,
                    "Please upload an image",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        boolean inserted = databaseHelper.insertItem(
                postType,
                name,
                phone,
                description,
                date,
                location,
                category,
                selectedImageUri,
                selectedLatitude,
                selectedLongitude
        );

        if (inserted) {

            Toast.makeText(this,
                    "Advert saved successfully",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(
                    CreateAdvertActivity.this,
                    ItemListActivity.class));

            finish();

        } else {

            Toast.makeText(this,
                    "Failed to save advert",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void handlePrefilledFoundAdvert() {

        String mode = getIntent().getStringExtra("mode");

        if (mode != null && mode.equals("found_from_lost")) {

            radioFound.setChecked(true);

            edtName.setText(getIntent().getStringExtra("name"));
            edtPhone.setText(getIntent().getStringExtra("phone"));
            edtDescription.setText(getIntent().getStringExtra("description"));
            edtLocation.setText(getIntent().getStringExtra("location"));

            selectedLatitude = getIntent().getDoubleExtra("latitude", 0.0);
            selectedLongitude = getIntent().getDoubleExtra("longitude", 0.0);

            if (selectedLatitude != 0.0 || selectedLongitude != 0.0) {
                locationSelected = true;
            }

            String category = getIntent().getStringExtra("category");

            if (category != null) {

                for (int i = 0; i < spinnerCategory.getCount(); i++) {

                    if (spinnerCategory.getItemAtPosition(i)
                            .toString().equals(category)) {

                        spinnerCategory.setSelection(i);
                        break;
                    }
                }
            }

            Toast.makeText(this,
                    "Found form pre-filled from lost advert",
                    Toast.LENGTH_SHORT).show();
        }
    }
}