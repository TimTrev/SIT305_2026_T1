package com.example.lostfoundapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    TextView txtTitle, txtDate, txtLocation, txtPhone, txtDescription, txtCategory;
    ImageView detailImage;
    Button btnFound, btnRemove, btnShowOnMap;

    DatabaseHelper databaseHelper;
    int itemId;
    LostFoundItem item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        txtTitle = findViewById(R.id.txtTitle);
        txtDate = findViewById(R.id.txtDate);
        txtLocation = findViewById(R.id.txtLocation);
        txtPhone = findViewById(R.id.txtPhone);
        txtDescription = findViewById(R.id.txtDescription);
        txtCategory = findViewById(R.id.txtCategory);
        detailImage = findViewById(R.id.detailImage);
        btnFound = findViewById(R.id.btnFound);
        btnRemove = findViewById(R.id.btnRemove);
        btnShowOnMap = findViewById(R.id.btnShowOnMap);

        databaseHelper = new DatabaseHelper(this);
        itemId = getIntent().getIntExtra("itemId", -1);

        if (itemId == -1) {
            Toast.makeText(this, "No item ID received", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadItemDetails();

        btnShowOnMap.setOnClickListener(v -> {

            Intent intent =
                    new Intent(ItemDetailActivity.this,
                            MapsActivity.class);

            intent.putExtra("singleItemMode", true);

            intent.putExtra("itemName", item.getName());
            intent.putExtra("itemType", item.getPostType());
            intent.putExtra("itemDescription", item.getDescription());

            intent.putExtra("latitude", item.getLatitude());
            intent.putExtra("longitude", item.getLongitude());

            startActivity(intent);
        });

        btnFound.setOnClickListener(v -> {
            boolean updated = databaseHelper.markItemAsFound(itemId);

            if (updated) {
                Toast.makeText(this, "Item marked as found", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        });

        btnRemove.setOnClickListener(v -> {
            boolean deleted = databaseHelper.deleteItem(itemId);

            if (deleted) {
                Toast.makeText(this, "Advert removed", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to remove advert", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadItemDetails() {
        item = databaseHelper.getItemById(itemId);

        if (item == null) {
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        txtTitle.setText(item.getPostType() + " item");
        txtDate.setText(item.getDate());
        txtLocation.setText("At " + item.getLocation());
        txtPhone.setText("Phone: " + item.getPhone());
        txtDescription.setText(item.getDescription());
        txtCategory.setText("Category: " + item.getCategory());

        if (item.getPostType().equalsIgnoreCase("Lost")) {
            btnFound.setVisibility(View.VISIBLE);
        } else {
            btnFound.setVisibility(View.GONE);
        }

        try {
            if (item.getImageUri() != null && !item.getImageUri().isEmpty()) {
                detailImage.setImageURI(Uri.parse(item.getImageUri()));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Image could not be loaded", Toast.LENGTH_SHORT).show();
        }
    }
}