package com.example.lostfoundapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap googleMap;

    DatabaseHelper databaseHelper;

    FusedLocationProviderClient fusedLocationClient;

    EditText edtRadius;
    Button btnApplyRadius;

    Location currentLocation;

    ActivityResultLauncher<String> locationPermissionLauncher;

    double radiusKm = 10.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        databaseHelper = new DatabaseHelper(this);

        fusedLocationClient =
                LocationServices.getFusedLocationProviderClient(this);

        edtRadius = findViewById(R.id.edtRadius);
        btnApplyRadius = findViewById(R.id.btnApplyRadius);

        setupLocationPermission();

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.mapFragment);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnApplyRadius.setOnClickListener(v -> {

            String radiusText =
                    edtRadius.getText().toString().trim();

            if (radiusText.isEmpty()) {

                Toast.makeText(this,
                        "Enter a radius in km",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            radiusKm = Double.parseDouble(radiusText);

            loadItemsOnMap();
        });
    }

    private void setupLocationPermission() {

        locationPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestPermission(),
                        isGranted -> {

                            if (isGranted) {

                                getCurrentLocation();

                            } else {

                                Toast.makeText(this,
                                        "Location permission required",
                                        Toast.LENGTH_SHORT).show();

                                loadItemsOnMapWithoutRadius();
                            }
                        });
    }

    @Override
    public void onMapReady(GoogleMap map) {

        googleMap = map;

        // Enable zoom controls
        googleMap.getUiSettings().setZoomControlsEnabled(true);

        // Enable pinch zoom gestures
        googleMap.getUiSettings().setZoomGesturesEnabled(true);

        // Enable compass
        googleMap.getUiSettings().setCompassEnabled(true);

        // Enable map toolbar
        googleMap.getUiSettings().setMapToolbarEnabled(true);

        // SINGLE ITEM MODE
        if (getIntent().getBooleanExtra("singleItemMode", false)) {
            showSingleItemOnMap();
            return;
        }

        // NORMAL MODE
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            locationPermissionLauncher.launch(
                    Manifest.permission.ACCESS_FINE_LOCATION);

            return;
        }

        googleMap.setMyLocationEnabled(true);

        getCurrentLocation();
    }

    private void showSingleItemOnMap() {

        double latitude =
                getIntent().getDoubleExtra("latitude", 0.0);

        double longitude =
                getIntent().getDoubleExtra("longitude", 0.0);

        String itemName =
                getIntent().getStringExtra("itemName");

        String itemType =
                getIntent().getStringExtra("itemType");

        String itemDescription =
                getIntent().getStringExtra("itemDescription");

        LatLng itemPosition =
                new LatLng(latitude, longitude);

        googleMap.clear();

        googleMap.addMarker(
                new MarkerOptions()
                        .position(itemPosition)
                        .title(itemType + ": " + itemName)
                        .snippet(itemDescription)
        );

        googleMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(
                        itemPosition,
                        16
                )
        );
    }

    private void getCurrentLocation() {

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        googleMap.setMyLocationEnabled(true);

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(location -> {

                    if (location != null) {

                        currentLocation = location;

                        loadItemsOnMap();

                    } else {

                        Toast.makeText(this,
                                "Could not get location",
                                Toast.LENGTH_SHORT).show();

                        loadItemsOnMapWithoutRadius();
                    }
                });
    }

    private void loadItemsOnMap() {

        if (googleMap == null) {
            return;
        }

        if (currentLocation == null) {
            loadItemsOnMapWithoutRadius();
            return;
        }

        googleMap.clear();

        ArrayList<LostFoundItem> items =
                databaseHelper.getAllItems();

        LatLngBounds.Builder builder =
                new LatLngBounds.Builder();

        LatLng userPosition =
                new LatLng(
                        currentLocation.getLatitude(),
                        currentLocation.getLongitude()
                );

        googleMap.addMarker(
                new MarkerOptions()
                        .position(userPosition)
                        .title("Your current location")
        );

        builder.include(userPosition);

        googleMap.addCircle(
                new CircleOptions()
                        .center(userPosition)
                        .radius(radiusKm * 1000)
        );

        int visibleCount = 0;

        for (LostFoundItem item : items) {

            Location itemLocation = new Location("");

            itemLocation.setLatitude(item.getLatitude());
            itemLocation.setLongitude(item.getLongitude());

            float distanceMeters =
                    currentLocation.distanceTo(itemLocation);

            double distanceKm =
                    distanceMeters / 1000.0;

            if (distanceKm <= radiusKm) {

                LatLng itemPosition =
                        new LatLng(
                                item.getLatitude(),
                                item.getLongitude()
                        );

                googleMap.addMarker(
                        new MarkerOptions()
                                .position(itemPosition)
                                .title(item.getPostType()
                                        + ": "
                                        + item.getName())
                                .snippet(item.getDescription())
                );

                builder.include(itemPosition);

                visibleCount++;
            }
        }

        googleMap.animateCamera(
                CameraUpdateFactory.newLatLngBounds(
                        builder.build(),
                        150
                )
        );

        Toast.makeText(this,
                visibleCount + " items found within "
                        + radiusKm + " km",
                Toast.LENGTH_SHORT).show();
    }

    private void loadItemsOnMapWithoutRadius() {

        if (googleMap == null) {
            return;
        }

        googleMap.clear();

        ArrayList<LostFoundItem> items =
                databaseHelper.getAllItems();

        if (items.isEmpty()) {

            Toast.makeText(this,
                    "No items available",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        LatLngBounds.Builder builder =
                new LatLngBounds.Builder();

        for (LostFoundItem item : items) {

            LatLng itemPosition =
                    new LatLng(
                            item.getLatitude(),
                            item.getLongitude()
                    );

            googleMap.addMarker(
                    new MarkerOptions()
                            .position(itemPosition)
                            .title(item.getPostType()
                                    + ": "
                                    + item.getName())
                            .snippet(item.getDescription())
            );

            builder.include(itemPosition);
        }

        googleMap.animateCamera(
                CameraUpdateFactory.newLatLngBounds(
                        builder.build(),
                        150
                )
        );
    }
}